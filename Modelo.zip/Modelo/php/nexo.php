<?php
require_once('alumno.php');
require_once('materia.php');
require_once('archivo.php');
$accion = isset($_POST['caso']) ? $_POST['caso'] : NULL;
//$alumno = isset($_POST['miObjeto']) ? json_decode(json_encode($_POST["miObjeto"])) : NULL;


switch ($accion) {
	case 'cargarAlumno':
    	Alumno::Alta($_POST,$_FILES);
    break;
	case 'consultarAlumno':
		Alumno::Obtener($_GET['apellido']);
	break;
	case "cargarMateria":
		Materia::cargarMateria($_POST);
	break;
	case "inscribirAlumno":
		Materia::inscribirAlumno($_GET);
	break;
	case 'inscripciones':
			

	break;
	case 'modificarAlumno':
		Alumno::Modificar($_POST);
	break;
	case 'Mostrartabla':
		$tabla = "<table border=1 align=center>
                    <thead>
                        <tr>
                            <th>NOMBRE</th>
                            <th>APELLIDO</th>
                            <th>EMAIL</th>
                            <th>FOTO</th>
                            <th>ACCION</th>
                        </tr>
                    </thead>";
    	$ListaAlumnos = Alumno::Obtener();//Lista (de obj php) de los alumnos guardados en el archivo
    	foreach ($ListaAlumnos as $alu) {
    		$jsonAlu = array();
    		$jsonAlu["Nombre"] = $alu->getNombre(); 
    		$jsonAlu["Apellido"] = $alu->getApellido();
    		$jsonAlu["Email"] = $alu->getEmail();
    		$jsonAlu["Foto"] = $alu->getPathFoto();
    		$jsonAlu = json_encode($jsonAlu);
	    	$tabla .= "<tr>
	    				<th>" . $alu->getNombre(). "</th>" . 
	    				"<th>" . $alu->getApellido() . "</th>" .
	    				"<th>" . $alu->getEmail() . "</th>" .
	    				"<th><img src='files/" . $alu->getPathFoto() . "' width='50px' height='50px'</th>" .
	    				"<th> 
	    				<button onclick='jqueryAjaxModificacion($jsonAlu)' id='modificacion'>Modificar</button>" .
	    				"<button onclick='jqueryAjaxBaja($jsonAlu)' id='baja'>Baja</button>" .
	    			   "</th>" .
	    			   "</tr>";
    	}    
    	$tabla .= "</table>";
    	echo $tabla;
    break;
	case 'Subirfotos':
		$result = Archivo::SubirArchivo();
		echo json_encode($result);
	break;

	default:
		echo "case incorrecto";
		break;
}
?>