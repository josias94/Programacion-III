<?php
class Usuario
{
    public $nombre;
    var $clave;

    function __construct($nombre,$clave)
    {
        $this->nombre = $nombre;
        $this->clave = $clave;
    }

    function ToString()
    {
        return json_decode($this);
    }

    function ToJSON()
    {
        return json_encode($this);
    }
}

?>