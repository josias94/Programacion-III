<?php
session_start();

include_once 'clases/alumno.php';
include_once 'clases/persona.php';
include_once 'clases/Funciones.php';

//var_dump($_GET);
//var_dump($_POST);
//var_dump($_REQUEST);
//var_dump($_COOKIE);
//var_dump($_SESSION);
$error = false;
$errormsg = "";


if($_SERVER ['REQUEST_METHOD'] == 'GET')
{
    if(isset($_GET["caso"]))
    {
        switch($_GET["caso"])
        {
            case "Alumno":
            Funciones::TraerListado();
            break;
            default:
            $error = true;
            $errormsg = "Caso desconocido";
            break;
        }
    }
    else
    {
        $error = true;
        $errormsg = "Falta Caso";
    }
}
else if($_SERVER ['REQUEST_METHOD'] == 'POST')
{
    if(isset($_POST["caso"]))
    {
        switch($_POST["caso"])
        {
            case "Alumno":
            Funciones::Guardar();
            break;
            default:
            $error = true;
            $errormsg = "Caso desconocido";
            break;
        }
    }
    else
    {
        $error = true;
        $errormsg = "Falta Caso";
    }
    
}

if($error)
{
    http_response_code(400);
    echo $errormsg;
}





if(isset($_REQUEST["destruir"]))
{
    session_unset();
    echo "\nSession destruida";
}
?>