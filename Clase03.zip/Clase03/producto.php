<?php
class producto
{
    public $nombre;
    public $codBarra;

    function __construct($nom,$cod)
    {
        $this->nombre = $nom;
        $this->codBarra = $cod;
    }

    function ToString()
    {
        return $this->nombre."-".$this->codBarra."\n";
    }
}

?>