<?php

class Funciones
{
    public static function Guardar($path, $obj)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 


        array_push($arrayTemp, $obj);

        $archivo = fopen($path,"w");
        fwrite($archivo,json_encode($arrayTemp));
        fclose($archivo);
    }

    public static function Leer($path)
    {
        $arrayJson = [];
        $archivo = fopen($path,"r");
        $len = filesize($path);
        if($len > 0)
        {
            $arrayJson = fread($archivo,$len);
        }
        fclose($archivo);
        return $arrayJson;
    }
    
    public static function Listar($path)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 

    }

    public static function Modificar($path, $key ,$keyValue, $newValue)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        var_dump($arrayAux);
        
        foreach($arrayTemp as $elem)
        {
            if($elem[$key] == $keyValue)
            {
                $elem[$key] = $newValue;
            }
        }
        var_dump($arrayAux);
    }
}
?>