<?php
class Alumno{
	public $nombre;
	public $apellido;
	public $email;  


    public function __construct($nom=NULL, $ape=NULL, $mail=NULL){
		if($nom!=NULL && $ape!=NULL && $mail!=NULL)
		{
			$this->nombre = $nom;
			$this->apellido = $ape;
			$this->email = $mail;
		}
	}
    
	public function toString(){	
		return $this->nombre . " - " . $this->apellido . " - " .  $this->email . "\n"; 
	}
	

	public static function Alta($post,$file){	
		$objAlumno = new Alumno($post['nombre'], $post['apellido'], $post['email']);

		//BASE24
		//$imagen = file_get_contents($file['foto']["tmp_name"]);
		//$imgBase = base64_encode($magen);
        $destino = Alumno::Mover($objAlumno, $file['foto']);
        $result = Alumno::Guardar($objAlumno, $destino);//$imgBase
	}

	public static function Mover($alumno, $foto){	
		$des = "../fotos/".$foto["name"];
		$string = explode(".",$des);
		$ext = $string[count($string)-1];
		$destino = "../fotos/".$alumno->email.".".$ext;
		if(file_exists($destino))
		{   
			copy($destino,"../backup/".$alumno->apellido.date("dmyHis").".".$ext);      
		}
		move_uploaded_file($foto["tmp_name"],$destino);
		
		return $destino;
		
	}

    public static function Guardar($alumno, $destino){
		$array = array();
		
		if(($archivo = fopen("../files/alumnos.txt", "r")) == false)
		{
			if(($archivo = fopen("../files/alumnos.txt", "w")) == false)
			{
				$alumno->pathfoto = $destino;
				array_push($array,$alumno);
				fwrite($archivo,json_encode($array));				
				fclose($archivo);
			}
		}
		else
		{				
			$str = fgets($archivo);
			if($str != "")
			{
				$array = json_decode($str);
			}						
			fclose($archivo);

			$archivo = fopen("../files/alumnos.txt", "w");

			$alumno->pathfoto = $destino;
			array_push($array,$alumno);	
			fwrite($archivo,json_encode($array));
			fclose($archivo);
		}		
	}

	public static function Obtener($apellido){
		$arrayAlumnos = array();
		$retorno = array();
		$archivo = fopen("../files/alumnos.txt", "r");
		
		$str = fgets($archivo);
		fclose($archivo);

		if($str != "")
		{
			$array = json_decode($str);
		}	
		//Convierte de Object a Alumno
		foreach ($array as $value){
			$aux = new Alumno($value->nombre, $value->apellido, $value->email);
			array_push($arrayAlumnos,$aux);			
		}		
		
		foreach ($arrayAlumnos as $alumno) 
		{
			if(strtolower($alumno->apellido) == strtolower($apellido))
			{
				array_push($retorno, $alumno);			
			}
		}
		
		if(count($retorno)==0)
		{
			echo "No existe alumno con apellido ". $apellido;
		}
		else
		{
			foreach ($retorno as $alum)
			{
				echo $alum->ToString()."<br>";
			}
		}	
		
		
	}



	
	public static function Borrar($obj)
	{
		$archivo = fopen("../files/alumnos.txt", "r");
		$arrayObj = array();
		$resultado = FALSE;
		while (!feof($archivo)) {
			$renglon = fgets($archivo);
			$renglon = explode("-", $renglon);
			if($renglon[0] != "")
			{
				$arrayObj[] = new Alumno(trim($renglon[0]), trim($renglon[1]), trim($renglon[2]));
			}
		}
		fclose($archivo);
		$archivo = fopen("../files/alumnos.txt", "w");
		foreach ($arrayObj as $alumno) {
			if($alumno == $obj)
				$resultado = TRUE;
			else
				fwrite($archivo, $alumno->toString());
		}
		fclose($archivo);
		return $resultado;
	}
	public static function Modificar($obj)
	{
		$arhivo = fopen("../files/alumnos.txt", "r");
		$arrayObj = array();
		$resultado = FALSE;
		while(!feof($arhivo))
		{
			$renglon = fgets($arhivo);
			$renglon = explode("-", $renglon);
			if($renglon[1] != "" && trim($renglon[1]) != $obj->apellido){
			$arrayObj[] = new Alumno(trim($renglon[0]) , trim($renglon[1]), trim($renglon[2])/*, trim($renglon[3])*/);
			}
			if($renglon[1] != "" && trim($renglon[1]) == $obj->apellido)//Además si machea el apellido ingresado con alguno de los alumnos en el archivo retorno TRUE
				$resultado = TRUE;
		}
		fclose($arhivo);
		if($resultado)//cargo el alumno modificado en caso de que lo haya encontrado
			array_push($arrayObj, $obj);
		$archivo = fopen("../files/alumnos.txt", "w");
		foreach ($arrayObj as $alumno) {
			$bytes = fwrite($archivo, $alumno->toString());
			if($bytes < 1)
			{
				$resultado = FALSE;
				break;
			}
		}
		fclose($archivo);
		return $resultado;
	}
	


}
?>