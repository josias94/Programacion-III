<?php

class Vehiculo 
{
    public $patente;
    public $marca;
    public $modelo;
    public $precio;

    public function __construct($patente, $marca, $modelo, $precio){
        $this->patente = $patente;
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->precio = $precio;
    }
}

?>