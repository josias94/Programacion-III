<?php 
	require "funciones.php";

	include "otroArchivo.php";

	Saludar();
	echo "<br/>";

	Saludar2("Juan");
	echo "<br/>";

	echo Saludar3("Rosa", "Femenino");
	echo "<br/>";

	echo Saludar3("Carlos");
	echo "<br/>";