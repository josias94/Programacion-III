<?php
class Alumno{
	public $nombre;
	public $apellido;
	public $email;  


    public function __construct($nom=NULL, $ape=NULL, $mail=NULL){
		if($nom!=NULL && $ape!=NULL && $mail!=NULL)
		{
			$this->nombre = $nom;
			$this->apellido = $ape;
			$this->email = $mail;
		}
	}
    
	public function toString(){	
		return $this->nombre . " - " . $this->apellido . " - " .  $this->email . "\n"; 
	}
	

	public static function Alta($post,$file){	
		$objAlumno = new Alumno($post['nombre'], $post['apellido'], $post['email']);

		//BASE24
		//$imagen = file_get_contents($file['foto']["tmp_name"]);
		//$imgBase = base64_encode($magen);
		//$destino = Alumno::Mover($objAlumno, $file['foto']);

		$des = "../fotos/".$file["foto"]["name"];
		$string = explode(".",$des);
		$ext = $string[count($string)-1];
		$destino = "../fotos/".$objAlumno->email.".".$ext;

        $result = Alumno::Guardar($objAlumno, $destino);//$imgBase
	}

	public static function Mover($alumno, $foto){	
		$des = "../fotos/".$foto["name"];
		$string = explode(".",$des);
		$ext = $string[count($string)-1];
		$destino = "../fotos/".$alumno->email.".".$ext;
		if(file_exists($destino))
		{   
			copy($destino,"../backup/".$alumno->apellido.date("dmyHis").".".$ext);      
		}
		move_uploaded_file($foto["tmp_name"],$destino);
		
		return $destino;
		
	}

    public static function Guardar($alumno, $destino){
		$array = array();
		
		if(($archivo = fopen("../files/alumnos.txt", "r")) == false)
		{
			if(($archivo = fopen("../files/alumnos.txt", "w")) == true)
			{
				$alumno->pathfoto = $destino;
				array_push($array,$alumno);
				fwrite($archivo,json_encode($array));				
				fclose($archivo);
			}
		}
		else
		{				
			$str = fgets($archivo);
			if($str != "")
			{
				$array = json_decode($str);
			}						
			fclose($archivo);
			$b = true;
			foreach ($array as $value){
				if($value->email == $alumno->email)
				{
					$b = false;
					echo "El email ".$alumno->email." ya esta en uso.<br>";
					break;
				}
			}
			if($b)
			{
				$archivo = fopen("../files/alumnos.txt", "w");
				$alumno->pathfoto = $destino;
				array_push($array,$alumno);	
				fwrite($archivo,json_encode($array));
				fclose($archivo);
			}		
		}		
	}

	public static function Obtener($apellido){
		$arrayAlumnos = array();
		$retorno = array();
		$archivo = fopen("../files/alumnos.txt", "r");
		
		$str = fgets($archivo);
		fclose($archivo);

		if($str != "")
		{
			$array = json_decode($str);
		}	
		//Convierte de Object a Alumno
		foreach ($array as $value){
			$aux = new Alumno($value->nombre, $value->apellido, $value->email);
			array_push($arrayAlumnos,$aux);			
		}		
		
		foreach ($arrayAlumnos as $alumno) 
		{
			if(strtolower($alumno->apellido) == strtolower($apellido))
			{
				array_push($retorno, $alumno);			
			}
		}
		
		if(count($retorno)==0)
		{
			echo "No existe alumno con apellido ". $apellido;
		}
		else
		{
			foreach ($retorno as $alum)
			{
				echo $alum->ToString()."<br>";
			}
		}	
		
		
	}

	public static function Modificar($post)
	{
		$newAlumno = new Alumno($post["nombre"],$post["apellido"],$post["email"]);
		if($archivo = fopen("../files/alumnos.txt", "r"))
		{
			$str = fgets($archivo);
			if($str != "")
			{
				$array = json_decode($str);
			}						
			fclose($archivo);

			foreach ($array as $alumno ){
				if($alumno->email == $newAlumno->email)
				{
					
					break;
				}
			}
		}
		else
		{
			echo "no hay alumnos cargados";
		}
	}
	


}
?>