<?php
include_once "/Clases/Usuario.php";

$num =-1;

$arrayGet=array();
foreach ($_GET as $key => $value) {
    array_push($arrayGet,$value);
}

$arrayPost=array();
foreach ($_POST as $key => $value) {
    array_push($arrayPost,$value);
}

$arrayUsuarios = array();
if(count($arrayGet) == count($arrayPost))
{
    for ($i=0; $i < count($arrayGet); $i++) { 
        array_push($arrayUsuarios, new usuario($arrayGet[$i],$arrayPost[$i]));
    }
}
var_dump($arrayUsuarios);


if(!file_exists("Datos"))
{
    mkdir("Datos");
}
else{
    $archivo = fopen("Datos/datos.json","w");
    //$num = fwrite($archivo,json_encode($usuario));
    //$num = fwrite($archivo,$usuario->ToJSON());
    //$num = fwrite($archivo,json_encode($array));

    foreach ($arrayUsuarios as $key => $value) {
        //llenar    
    }
    fclose($archivo); 

    $file = fopen("Datos/datos.json","r");
    $str = fread($file,100);

    $array = json_decode($str);
    var_dump($array);    
  
}
var_dump($num);


?>