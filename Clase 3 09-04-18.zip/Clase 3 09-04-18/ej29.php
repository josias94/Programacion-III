<!doctype html>
<html>
	<body style = "background-color: #FF0000 ">
		<form id = "color" method = "$_GET">
            <select name = "color">
			    <option value = "#FF0000">Rojo</option>
			    <option value = "#00FF00">Verde</option>
			    <option value = "#0000FF">Azul</option>
			    <option value = "#FF00FF">Violeta</option>
		    </select>
		    <input type="submit" name="CambiarColor" value="Cambiar Color"
		    onclick = >
         </form>
	</body>

</html>