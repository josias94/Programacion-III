<?php
include_once "producto.php";
include_once "../Funciones.php";

$archivo = fopen("Archivo.txt","w");

$producto = new producto($_POST["nombre"],$_POST["codBarra"]);

fwrite($archivo,$producto->ToString());


//var_dump($_FILES);
$destino = "Fotos/".$_FILES["imagen"]["name"];


//funciona por puntos

$string = explode(".",$destino);
$ext = $string[count($string)-1];
$destino = "Fotos/".trim($producto->ToString()).".".$ext;


/*
funciona por barra
$pos = strpos($_FILES["imagen"]["type"],"/");
$ext = substr($_FILES["imagen"]["type"],$pos+1);
$destino = "Fotos/".trim($producto->ToString()).".".$ext;
*/

if(file_exists($destino))
{
    MoverArchivo($destino,"BackUp/".trim($producto->ToString())."-".date("dmyHis").".".$ext);   
    //copy($destino,"BackUp/".trim($producto->ToString())."-".date("dmyHis").".".$ext);      
}
move_uploaded_file($_FILES["imagen"]["tmp_name"],$destino);


/*
mover archivo (origen,destino)
armar un json con nombre-codigo-path 
tabla 
devolvemos por get

listado cada una con su foto

-------------
busqueda y logica

funccion patra el horario internacional en servidor
*/








?>