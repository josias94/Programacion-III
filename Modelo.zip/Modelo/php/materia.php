<?php
class Materia{
	public $nombre;
    public $codigo;
    public $cupo;
    public $aula;
    
	public function __construct($nom=NULL, $cod=NULL, $cupo=NULL, $aula=NULL){
		if($nom!=NULL && $cod!=NULL && $cupo!=NULL && $aula!=NULL)
		{
			$this->nombre = $nom;
            $this->codigo = $cod;
            $this->cupo = $cupo;
            $this->aula = $aula;
		}
	}

	public function toString(){
		return $this->_nombre . "-" . $this->_email . "\n"; 
	}
	
	public static function cargarMateria($post){
		$materia = new Materia($post["nombre"],$post["codigo"],$post["cupo"],$post["aula"]);
		Materia::GuardarMateria($materia);
	}

	public static function GuardarMateria($materia){
		$array = array();
		
		if(($archivo = fopen("../files/materias.txt", "r")) == false)
		{
			if(($archivo = fopen("../files/materias.txt", "w")) == true)
			{
				array_push($array,$materia);
				fwrite($archivo,json_encode($array));				
				fclose($archivo);
			}
		}
		else
		{				
			$str = fgets($archivo);
			if($str != "")
			{
				$array = json_decode($str);
			}						
			fclose($archivo);

			$b = true;
			foreach ($array as $value) {
				if($value->codigo == $materia->codigo)
				{
					$b = false;
					echo "El codigo de la materia ".$materia->codigo." ya esta en uso";
					break;
				}
			}
			if($b)
			{
				$archivo = fopen("../files/materias.txt", "w");
				array_push($array,$materia);	
				fwrite($archivo,json_encode($array));
				fclose($archivo);
			}
		}		
	}

	public static function inscribirAlumno($get){
		if(($archivo = fopen("../files/materias.txt", "r")) == true)
		{
			$str = fgets($archivo);
			if($str != "")
			{
				$array = json_decode($str);
			}						
			fclose($archivo);
		}
		else
		{
			echo "No hay materias disponibles";
		}
		$b = true;
		foreach ($array as $materia){
			if($materia->nombre == $get["materia"])
			{
				$b = false;
				if($materia->cupo > 0)
				{
					$materia->cupo--;		
					Materia::Inscribir($get,$array);		
				}
				else{
					echo "La materia ".$get["materia"]." tiene el cupo lleno.";
				}
				break;
			}
		}
		if($b)
		{
			echo "La materia ".$get["materia"]." no se encuentra disponible.";
		}
		else
		{
			$archivo = fopen("../files/materias.txt", "w");	
			fwrite($archivo,json_encode($array));
			fclose($archivo);
		}
	}

	public static function Inscribir($get){
		$array = array();
		if(($archivo = fopen("../files/inscripciones.txt", "r")) == false)
		{
			if(($archivo = fopen("../files/inscripciones.txt", "w")) == true)
			{
				array_push($array,$get);
				fwrite($archivo,json_encode($array));				
				fclose($archivo);
			}
		}
		else
		{				
			$str = fgets($archivo);
			if($str != "")
			{
				$array = json_decode($str);
			}						
			fclose($archivo);
			$archivo = fopen("../files/inscripciones.txt", "w");
			//alumno duplicado?
			array_push($array,$get);	
			fwrite($archivo,json_encode($array));
			fclose($archivo);
		}
	}

    

}
?>