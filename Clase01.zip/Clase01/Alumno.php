<?php
	class Alumno 
	{
		public $legajo;

		function Saludar()
		{
			return "Hola ".$this->legajo;
		}
	}
?>