<?php
 
include "clases/persona.php";

class Alumno extends Persona
{
    
}

?>