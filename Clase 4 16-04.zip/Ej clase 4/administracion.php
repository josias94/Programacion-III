<?php
$destino = "uploads/".date("y_m_d_h_i_s_f").$_FILES["archivo"]["name"];
$uploadOK = true;

$tipoDeArchivo = pathinfo($destino, PATHINFO_EXTENSION);

if(file_exists($destino))
{
    echo "El archivo ya existe";
    $uploadOK = false;
}
if($tipoDeArchivo != "jpg" && $tipoDeArchivo != "jpeg" && $tipoDeArchivo != "png"&& $tipoDeArchivo != "gif")
{
    echo "solo son permitidas imagenes con extencion jpg....etc";
    $uploadOK = false;
}

if($uploadOK)
{
    move_uploaded_file($_FILES["archivo"]["tmp_name"],$destino);
    $archivo = fopen("fotos.txt","a");

    fwrite($archivo,$destino."\r\n");

    require_once("visor.php");
    echo "<br><a href='index.html'>Volver</a>";
}
?>
