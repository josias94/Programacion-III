<?php

class Persona{
    public $nombre;
    public $apellido;
    
    public function __construct($nombre, $apellido){
        $this->nombre = $nombre;
        $this->apellido = $apellido;
    }

    public function Mostrar()
    {
        return $this->nombre." ".$this->apellido;;
    }

    public function Encode()
    {
        return json_encode($this);
    }

    public function Decode($data)
    {
        return json_decode($data);
    }
}


?>