window.addEventListener('load',asignarManejadores);

function asignarManejadores()
{
    document.getElementById("btnCambiarTexto").addEventListener('click',cambioTexto);
    document.getElementById("btnCambiarClase").addEventListener('click',cambioClase);
    document.getElementById("btnSacarClase").addEventListener('click',SacoClase);
}

function cambioTexto()
{
    document.getElementById('p1').innerHTML = "Otro Texto p1";
    //array
    document.getElementsByTagName('p')[1].innerHTML = "Otro Texto p2";
    //array
    document.getElementsByClassName("ClaseP")[0].innerHTML = "Otro Texto p3";
    var div = document.getElementById('DivParrafos');
    div.getElementsByTagName("p")[3].innerHTML = "Otro texto p4";
}

function cambioClase()
{
    //document.getElementById("p2").setAttribute("class","ClaseP");
    document.getElementById("p2").className = "ClaseP";
}

function SacoClase()
{
    //document.getElementById("p3").setAttribute("class","");
    document.getElementById("p3").removeAttribute("class");
}