<?php
include_once 'turno.php';

class Funciones
{
    public static function CargarVehiculo($path, $obj)
    {
        $valido = Funciones::ValidarPatente($path, $obj);
        $HTTPstatus = 200;
        if($valido)
        {
            Funciones::Alta($path, $obj);
        }
        else
        {
            echo "Patente repetida";
            $HTTPstatus = 400;
        }
        return $HTTPstatus;
    }
    public static function CargarTipoServicio($path, $obj)
    {
        $HTTPstatus = 200;
        try 
        {
            Funciones::Alta($path, $obj);   
        }
        catch (\Throwable $th)
        {
            $HTTPstatus = 400;
        }
        
        return $HTTPstatus;
    }
    
    public static function ConsultarVehiculo($path, $param)
    {
        $array = Funciones::DecodeFile($path);
        $arrayRetorno = [];
        $found;

        if(isset($param["marca"]))
        {
            $key = "marca";
            $found = $param["marca"];
        }
        else if(isset($param["modelo"]))
        {
            $key = "modelo";
            $found = $param["modelo"];
        }
        else if(isset($param["patente"]))
        {
            $key = "patente";
            $found = $param["patente"];
        }
        if(isset($key))
        {
            $arrayRetorno = Funciones::FilterForParam($array, $key, $found); 
            if(count($arrayRetorno) == 0 )
            {
                echo("No existe ".$found);
            }            
        }
        
        return $arrayRetorno;
    }
    
    public static function Turnos($path)
    {
        return Funciones::DecodeFile($path);
    }

    public static function Inscripciones($path)
    {
        $array = Funciones::DecodeFile($path);
        $arrayRetorno = [];
        $found;

        if(isset($param["tipoServicio"]))
        {
            $key = "tipoServicio";
            $found = $param["tipoServicio"];
        }
        else if(isset($param["fecha"]))
        {
            $key = "fecha";
            $found = $param["fecha"];
        }

        if(isset($key))
        {
            $arrayRetorno = Funciones::FilterForParam($array, $key, $found); 
            if(count($arrayRetorno) == 0 )
            {
                echo("No existe ".$found);
            }            
        }
        
        return $arrayRetorno;
    }

    public static function ValidarPatente($path, $obj)
    {
        $arrayAux = json_decode(Funciones::Leer($path));   
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        $patente = $obj->patente;
        $cargar = true;
        foreach ($arrayTemp as $elem)
        {
            if($elem->patente == $patente)
            {
                $cargar = false;
                break;
            }
        }
        return $cargar;        
    }
    public static function SacarTurno($path,$pathVehiculos,$pathServicios,$params)
    {
        $arrayVehiculos = Funciones::DecodeFile($pathVehiculos);
        $arrayServicios = Funciones::DecodeFile($pathServicios);

        $vehiculo = Funciones::FilterForParam($arrayVehiculos, "patente", $params["patente"]); 
        $precio = $vehiculo[0]->precio;

        $servicio = Funciones::FilterForParam($arrayServicios, "precio", $precio); 
        
        $obj = new Turno($params["fecha"], $params["patente"], $vehiculo[0]->marca, $vehiculo[0]->modelo, $servicio[0]->precio, $servicio[0]->tipo);

        $HTTPstatus = 200;
        try 
        {
            Funciones::Alta($path, $obj);   
        }
        catch (\Throwable $th)
        {
            $HTTPstatus = 400;
        }
        return $HTTPstatus;
    }
    public static function ModificarVehiculo($path, $args, $files)
    {
        $array = Funciones::DecodeFile($path);
        $arrayfinal = [];
        if(isset($args["patente"]))
        {
            foreach ($array as $elem)
            {
                $obj = $elem;
                if(strtolower($elem->patente) == strtolower($args["patente"]))
                {
                    
                    if(isset($args["marca"]))
                    {
                        $obj->marca = $args["marca"];
                    }
                    if(isset($args["modelo"]))
                    {
                        $obj->modelo = $args["modelo"];
                    }
                    if(isset($args["precio"]))
                    {
                        $obj->precio = $args["precio"];
                    }
                    if(isset($files["imagen"]))
                    {

                        $destino = "Fotos/";
                        $nombreAnterior = $files["imagen"]->getClientFilename();
                        $extension = explode(".", $nombreAnterior);
                        $extension = array_reverse($extension);
                        if(file_exists($destino.$args["patente"].".".$extension[0]))
                        {
                            copy($destino.$args["patente"].".".$extension[0], "Backup/".$args["patente"].".".$extension[0]);
                        }
                        $files["imagen"]->moveTo($destino.$args["patente"].".".$extension[0]);
                    }
                }  
                array_push($arrayfinal, $obj);  
            } 
        }
        Funciones::Escribir($path, $arrayfinal);
        return $arrayfinal;
    }

    public static function Vehiculos($path)
    {
        $array = Funciones::DecodeFile($path);
        foreach ($array as $elem)
        {
            $pathfile = "Fotos/".$elem->patente.".jpg";
            if(file_exists($pathfile))
            {
                echo("<img src='$pathfile'><br>");
            }
            echo(JSON_encode($elem)."<br>");
        }
        return $array;
    }

#region GENERICO
    public static function FilterForParam($array, $key, $found)
    {
        $arrayRetorno = [];
        foreach ($array as $elem)
        {
            if(strtolower($elem->$key) == strtolower($found))
            {
                array_push($arrayRetorno, $elem);
            }    
        }   
        return $arrayRetorno;
    }

    public static function Alta($path, $obj)
    {
        $arrayAux = json_decode(Funciones::Leer($path));   
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = [];     
        array_push($arrayTemp, $obj);
        Funciones::Escribir($path, $arrayTemp);
    }

    public static function Leer($path)
    {
        $arrayJson = [];
        $archivo = fopen($path,"r");
        $len = filesize($path);
        if($len > 0)
        {
            $arrayJson = fread($archivo,$len);
        }
        fclose($archivo);

        return $arrayJson;
    }
    
    public static function DecodeFile($path)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        return $arrayAux;
    }

    public static function Modificar($path, $idName, $idValue, $key, $newValueKey)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        foreach($arrayTemp as $elem)
        {            
            if(isset($elem->$key) && isset($elem->$idName))
            {
                if($elem->$idName == $idValue)
                {
                    $elem->$key = $newValueKey;
                    break;
                }
            }
        }
        Funciones::Escribir($path, $arrayTemp);
        return $arrayTemp;
    }


    public static function Borrar($path, $args)
    {
        $legajo = $args;

        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = array();
        $arrayFinal = array();
        foreach($arrayTemp as $elem)
        {
            if($elem->legajo != $legajo)
            {
                array_push($arrayFinal,$elem);
            }
        }
        Funciones::Escribir($path, $arrayFinal);
    }

    public static function Escribir($path, $arrayObj)
    {
        $archivo = fopen($path,"w");
        fwrite($archivo,json_encode($arrayObj));
        fclose($archivo);
    }
}
#endregion

?>