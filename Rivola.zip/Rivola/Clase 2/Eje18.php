<?php
require "../Funciones.php";

echo EsPar(2);

echo EsImpar(3);
?>