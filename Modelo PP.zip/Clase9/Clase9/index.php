<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Slim\App as App;

require 'vendor/autoload.php';
include_once 'Funciones\Funciones.php';
include_once 'Funciones\vehiculo.php';
include_once 'Funciones\servicio.php';



$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new App(["settings" => $config]);


//1
$app->post('/cargarVehiculo', function(Request $request,Response $response){
    $path = "vehiculos.json";       
    $args = $request->getParsedBody();
    $vehiculo = new Vehiculo($args["patente"], $args["marca"], $args["modelo"], $args["precio"]); 
    $HTTPstatus = Funciones::CargarVehiculo($path, $vehiculo);     
    return $response->withJson($vehiculo, $HTTPstatus);
});
//2
$app->get('/consultarVehiculo', function(Request $request,Response $response){      
    $path = "vehiculos.json";
    $param = $request->getQueryParams();
    $array = Funciones::ConsultarVehiculo($path, $param); 
    $HTTPstatus = count($array) ? 200 : 400;
    $response->getBody()->write(json_encode($array));
    return $response->withJson($array, $HTTPstatus);
});
//3
$app->post('/cargarTipoServicio', function(Request $request,Response $response){
    $path = "tiposServicio.json";       
    $args = $request->getParsedBody();
    $servicio = new Servicio($args["id"], $args["tipo"], $args["precio"], $args["demora"]); 
    $HTTPstatus = Funciones::CargarTipoServicio($path, $servicio);     
    return $response->withJson($servicio, $HTTPstatus);
});
//4
$app->get('/sacarTurno', function(Request $request,Response $response){      
    $path = "turnos.json";
    $pathVehiculos = "vehiculos.json";
    $pathServicios = "tiposServicio.json";
    $params = $request->getQueryParams();
    $HTTPstatus = Funciones::SacarTurno($path, $pathVehiculos, $pathServicios,$params); 
    return $response->withJson($response, $HTTPstatus);
});
//5
$app->get('/turnos', function(Request $request,Response $response){      
    $path = "tiposServicio.json";
    $array = Funciones::Turnos($path); 
    $HTTPstatus = count($array) ? 200 : 400;
    $response->getBody()->write(json_encode($array));
    return $response->withJson($array, $HTTPstatus);
});
//6
$app->get('/inscripciones', function(Request $request,Response $response){      
    $path = "tiposServicio.json";
    $param = $request->getQueryParams();
    $array = Funciones::Inscripciones($path, $param); 
    $HTTPstatus = count($array) ? 200 : 400;
    //$response->getBody()->write(json_encode($array));
    return $response->withJson($response, $HTTPstatus);
});
//7
$app->post('/modificarVehiculo', function(Request $request,Response $response){
    $path = "vehiculos.json";       
    $args = $request->getParsedBody(); 
    $files = $request->getUploadedFiles();
    $array = Funciones::ModificarVehiculo($path, $args, $files);     
    $HTTPstatus = count($array) ? 200 : 400;
    return $response->withJson($response, $HTTPstatus);
});
//8
$app->get('/vehiculos', function(Request $request,Response $response){      
    $path = "vehiculos.json";
    $param = $request->getQueryParams();
    $array = Funciones::Vehiculos($path); 
    $HTTPstatus = count($array) ? 200 : 400;
    //$response->getBody()->write(json_encode($array));
    return $response;
});



$app->run();
?>
    