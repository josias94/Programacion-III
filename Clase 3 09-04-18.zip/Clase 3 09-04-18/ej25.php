<?php
    $file = fopen("Mis Archivos\palabras.txt","r");
    $cont1=0;
    $cont2=0;
    $cont3=0;
    $cont4=0;
    $cont5=0;
    while(!feof($file))
    {   
        $linea = fgets($file);
        
        $array = str_word_count($linea, 1);
        
        for($i=0;$i<count($array);$i++)
        {
           
            $cantLetras=strlen($array[$i]);
            
            switch ($cantLetras)
            {
                case 1:
                    $cont1++;
                break;
                case 2:
                    $cont2++;
                break;
                case 3:
                    $cont3++;
                break;
                case 4:
                    $cont4++;
                break;
                default:
                    $cont5++;
                break;
            }
        }
    }

 
?>
<!doctype html>
<html>
    <body>
        <table border = "2">
        <tr>
            <td>UNA</td>
            <td>DOS</td>
            <td>TRES</td>
            <td>CUATRO</td>
            <td>MAS DE CUATRO</td>
        </tr>
            
        <tr>
            <td><?php echo $cont1;?></td>
            <td><?php echo $cont2;?></td>
            <td><?php echo $cont3;?></td>
            <td><?php echo $cont4;?></td>
            <td><?php echo $cont5;?></td>
        </tr>
        </table>
    </body>


</html>
