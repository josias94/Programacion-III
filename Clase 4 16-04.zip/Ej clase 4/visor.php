<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Page Title</title>    
</head>
<body>
    <table border="1" align="center">
        <?php
        $file = fopen("fotos.txt","r");
        while(!feof($file))
        {
            $img = fgets($file);
            echo $img;
            if($img =! "")
            {
                echo "<tr>
                        <td>
                            <img src=".$img." width='100px' heigth='100px'>
                        </td>
                      </tr>";
            }
        }
        fclose($file);
        ?>
        
    </table>
</body>
</html>