<?php
	include_once "Alumno.php" ;
	include_once "Funciones.php";
	//require_once "Funciones.php";

    $nombre = "Josias";
    echo "Hola $nombre<br>";

    echo suma(5,6);
    echo "<br>";
    echo var_dump($nombre);
    echo "<br>";
    echo "<br>";
    echo var_dump(suma(3,4));

	echo "<br>";
    $array = array(2,"hola",3.5);
    var_dump($array);

    echo "<br>";
    echo "<br>";
    foreach ($array as $elemento) {
    	echo $elemento;
    	echo "<br>";
    }
    echo "<br>";
    echo "<br>";
    $arrayClaveValor = array('Alfa' => 666,"Betha"=>555,"Gama"=>444);
    var_dump($arrayClaveValor);
    echo "<br>";
    foreach ($arrayClaveValor as $key => $value) {
    	echo "Clave: ".$key." Valor: ".$value."<br>";
    }
    echo "<br>";
    echo "<br>";
    echo "<br>";

    $arrayClaveValor = "otra cosa nose";

    $nose = [];
    $obj = new stdclass();
    $obj -> nombre = "Josias";
    
    var_dump($obj);

    echo "<br>";
    echo "<br>";
    //echo Alumno::Saludar();
	echo "<br>";

    $alumno = new Alumno();
    $alumno->legajo = "12345";
    echo $alumno->Saludar();













?>
