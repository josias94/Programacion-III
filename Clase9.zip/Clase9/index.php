<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use \Slim\App as App;

require 'vendor/autoload.php';
include_once 'Funciones\Funciones.php';
include_once 'Funciones\alumno.php';



$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new App(["settings" => $config]);

$app->get("[/]",function(Request $req,Response $resp){
    return $resp;   
});


$app->group('/Usuarios',function(){

    $this->get('[/]', function(Request $request,Response $response){      
        $path = "Archivo.json";
        $array = Funciones::Listar($path);
        $response->getBody()->write(json_encode($array));
        return $response->withJson($array, 200);;
    });

    $this->post('[/]', function(Request $request,Response $response, $args){
        $arrayParams = $request->getParsedBody();

        $titulo =  $arrayParams['Titulo'];
        $archivos = $request->getUploadedFiles();
        $destino = "Fotos/";
        $nombreAnterior = $archivos['imagen']->getClientFilename();
        $extencion = explode(".", $nombreAnterior);
        $extencion = array_reverse($extencion);
        $archivos["imagen"]->moveTo($destino.$titulo.".".$extencion[0]);
        return $response;
    });

    $this->post('/new', function(Request $request,Response $response){
        $path = "Archivo.json";        
        $args = $request->getParsedBody();
        $al = new Alumno($args["nombre"], $args["apellido"], $args["legajo"]); 
        Funciones::Alta($path,$al);
        return $response->withJson($al, 200);
    });

    $this->put('/edit', function(Request $request,Response $response){
        $path = "Archivo.json";        
        $args = $request->getParsedBody();
        Funciones::Modificar($path, $args["idName"],$args["idValue"],$args["key"],$args["newValueKey"]);
        return $response->withJson($r,200);
    });

    $this->delete('/delete', function(Request $request,Response $response){
        $path = "Archivo.json";        
        $args = $request->getParsedBody();
        //var_dump($args);
        Funciones::Borrar($path, $args["legajo"]);
        return $response;
    });

});





$app->run();
?>
    