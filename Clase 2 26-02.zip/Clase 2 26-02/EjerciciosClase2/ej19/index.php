<?php
include "FiguraGeometrica.php";
include "Rectangulo.php";
include "Triangulo.php";

$rectangulo = new Rectangulo(10,40);
$rectangulo->SetColor("Red");
$triangulo = new Triangulo(3,5);
$triangulo->SetColor("#00FF00");
echo $rectangulo->ToString();
echo "<br><br>";
echo $triangulo->ToString();

?>