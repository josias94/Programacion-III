<?php
	require "../Funciones.php";

	for($i=0;$i<4;$i++)
	echo potencia($i);
	
	
	
?>