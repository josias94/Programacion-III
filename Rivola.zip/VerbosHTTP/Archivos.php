<?php
include_once "/Clases/Usuario.php";

$num =-1;
$array = array($usu1 = new Usuario("aaaa","1111"),
               $usu2 = new Usuario("bbbb","2222"),
               $usu3 = new Usuario("cccc","3333")); 


$usuario = new Usuario("aaa","1234");

if(!file_exists("Datos"))
{
    mkdir("Datos");
}
else{
    $archivo = fopen("Datos/datos.json","w");
    //$num = fwrite($archivo,json_encode($usuario));
    //$num = fwrite($archivo,$usuario->ToJSON());
    //$num = fwrite($archivo,json_encode($array));

    $num = fwrite($archivo,json_encode($array));
    fclose($archivo); 

    $file = fopen("Datos/datos.json","r");
    $str = fread($file,100);

    $array = json_decode($str);
    var_dump($array);    
    
}


var_dump($num);


?>