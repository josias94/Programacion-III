<?php
require "../Funciones.php";

 echo nose("parci",10);

?>