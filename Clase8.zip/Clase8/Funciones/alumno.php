<?php
 
include_once 'Funciones\persona.php';

class Alumno extends Persona
{
    public $legajo;

    public function __construct($nombre, $apellido, $legajo){
        parent::__construct($nombre, $apellido);
        $this->legajo = $legajo;
    }
}

?>