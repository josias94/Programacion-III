<?php

class Funciones
{
    public static function Guardar($path, $obj)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 

        array_push($arrayTemp, $obj);

        $archivo = fopen($path,"w");
        fwrite($archivo,json_encode($arrayTemp));
        fclose($archivo);
    }

    public static function Leer($path)
    {
        $arrayJson = [];
        $archivo = fopen($path,"r");
        $len = filesize($path);
        if($len > 0)
        {
            $arrayJson = fread($archivo,$len);
        }
        fclose($archivo);
        return $arrayJson;
    }
    
    public static function Listar($path)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        return $arrayAux;
    }

    public static function Modificar($path, $args)
    {
        $legajo = $args;
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        //var_dump($arrayAux);
        foreach($arrayTemp as $elem)
        {
            echo "ELEMENT";
            var_dump($elem->legajo);
            echo "LEGAJO";
            var_dump($legajo);

            if($elem->legajo == $legajo)
            {
                echo "HOLA";
                $elem->nombre = "NuevoNombre";
               break;
            }
        }
        var_dump($arrayAux);
    }
}
// class Funciones
// {
//     public static function StartSession()
//     {
//         if(!isset($_SESSION["array"]))
//         {
//             $_SESSION["array"] = [];
//             $arrayGet = [];
//         }
//         else
//         {
//             $arrayGet = $_SESSION["array"];
//         }
//         return $arrayGet;
//     }

//     public static function TraerListado()
//     {
//         $arrayGet = Funciones::StartSession();
//         $arrayGet = $_SESSION["array"];
//         echo json_encode($arrayGet);       
//     }

//     public static function Guardar($path , $elem)
//     {
//         $file = fopen($path,"a");
//         $arrayGet = [];
//         array_push($arrayGet, $elem);
//         fwrite($file,json_encode($arrayGet)); 

//         return fclose($file);
        
//     }
// }


?>