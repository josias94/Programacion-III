window.addEventListener('load',asignarManejadores);

function asignarManejadores()
{
    document.getElementById("btnCrearParrafo").addEventListener('click',crearParrafo);
    document.getElementById("btnCrearImagen").addEventListener('click',crearImagen);
    document.getElementById("btnBorrarUltimo").addEventListener('click',borrarUltimo);
    document.getElementById("btnBorrarPrimero").addEventListener('click',borrarPrimero);
    document.getElementById("btnSustituir").addEventListener('click',Sustituir);
}

function crearParrafo()
{
    var parrafo = document.createElement("p");
    var texto = document.createTextNode(document.getElementById("txtArea").value);
    parrafo.appendChild(texto);
    document.getElementById("div1").appendChild(parrafo);
    //document.getElementById("").setAttribute("class","ClaseP");
}

function crearImagen()
{
    var imagen = document.createElement("img");
    imagen.setAttribute("src", "imagen.jpg");
    imagen.height = "150";
    imagen.alt = "foto";
    document.getElementById("div1").appendChild(imagen);
}
function borrarUltimo()
{
    var div = document.getElementById("div1");
    var hijo = div.lastChild;
    div.removeChild(hijo);
}

function borrarPrimero()
{
    var div = document.getElementById("div1");
    var hijo = div.firstChild;
    div.removeChild(hijo);
}

function Sustituir()
{
    var parrafo = document.createElement("p");
    var texto = document.createTextNode("Hola Mundo");
    parrafo.appendChild(texto);
    document.getElementById("div1").replaceChild(parrafo,document.getElementById("div1").firstChild);
}