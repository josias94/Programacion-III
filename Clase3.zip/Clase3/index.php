<?php
include_once 'guardar.php';

include_once 'clases\alumno.php';
include_once 'clases\persona.php';

$path = "archivo.txt";
$error = false;

/*falta listar modificar y creo que insertar pero nose*/ 
if($_SERVER ['REQUEST_METHOD'] == 'GET')
{
    if(isset($_GET["case"]))
    {
        switch($_GET["case"])
        {
            case "Leer":
            echo Funciones::Leer($path);
            break;
            default:
            $error = true;
            $errormsg = "Case desconocido";
            break;
        }
    }
    else
    {
        $error = true;
        $errormsg = "Falta Case";
    }
}

if($_SERVER ['REQUEST_METHOD'] == 'POST')
{
    if(isset($_POST["case"]))
    {
        switch($_POST["case"])
        {
            case "Guardar":
            $al = new Alumno($_POST["nombre"], $_POST["apellido"], $_POST["legajo"]); 
            Funciones::Guardar($path,$al);
            $error = false;
            break;
            default:
            $error = true;
            $errormsg = "Case desconocido";
            break;
        }
    }
    else
    {
        $error = true;
        $errormsg = "Falta Case";
    }
    
}

if($_SERVER ['REQUEST_METHOD'] == 'POST')
{
    if(isset($_POST["case"]))
    {
        switch($_POST["case"])
        {
            case "Modificar":
            $legajo = $_POST["legajo"];
            $key = $_POST["key"];
            $newValue = $_POST["newValue"];
            $error = false;
            Funciones::Modificar($path,$key,$keyValue,$newValue);
            break;
            default:
            $error = true;
            $errormsg = "Case desconocido";
            break;
        }
    }
    else
    {
        $error = true;
        $errormsg = "Falta Case";
    }
}
if($error)
{
    http_response_code(400);
    echo $errormsg;
}





if(isset($_REQUEST["destruir"]))
{
    session_unset();
    echo "\nSession destruida";
}

/*
//copy($path,$path." - Copia");
//unlink($path."- Copia");//BORRAR
fclose($archivo);
*/

?>