<?php

class Funciones
{
    public static function StartSession()
    {
        if(!isset($_SESSION["array"]))
        {
            $_SESSION["array"] = [];
            $arrayGet = [];
        }
        else
        {
            $arrayGet = $_SESSION["array"];
        }
        return $arrayGet;
    }

    public static function TraerListado()
    {
        $arrayGet = Funciones::StartSession();
        $arrayGet = $_SESSION["array"];
        echo json_encode($arrayGet);       
    }

    public static function Guardar()
    {
        $arrayGet = Funciones::StartSession();
        $arrayGet = $_SESSION["array"];

        $al = new Alumno($_POST["nombre"], $_POST["apellido"]); 
        array_push($arrayGet, $al);

        $_SESSION["array"] = $arrayGet;
        echo "Guardado";   
    }
}


?>