<?php
	require "../Funciones.php";

	echo Invertir("Hola");

?>