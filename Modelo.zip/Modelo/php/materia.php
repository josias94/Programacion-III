<?php
class Materia{
	public $_nombre;
    public $_codigo;
    public $_cupo;
    public $_aula;
    
	public function __construct($nom=NULL, $cod=NULL, $cupo=NULL, $aula=NULL)
	{
		if($nom!=NULL && $cod!=NULL && $cupo!=NULL && $aula!=NULL)
		{
			$this->_nombre = $nom;
            $this->_codigo = $cod;
            $this->_cupo = $cupo;
            $this->_aula = $aula;
		}
    }
	public static function Guardar($obj)
	{
		
		$archivo=fopen("../files/materias.txt", "a");
		fwrite($archivo, $obj->toString());
		
		fclose($archivo);
	
	}
	/*public static function Login($usu)//retorna un bool que indica si pudo guardar ok
	{
		$resultado = FALSE;
		$archivo=fopen("../files/usuario.txt", "r");
		$resultado = FALSE;
		while(!feof($archivo))
		{
			$renglon = fgets($archivo);
			$renglon = explode("-", $renglon);
			if($renglon[0] != "" && trim($renglon[0]) == $usu->_nombre && trim($renglon[1]) == $usu->_email){
				$resultado = TRUE;
			}
		}
		fclose($archivo);
		return $resultado;
    }*/
    //TOSTRING
	public function toString()
	{
		return $this->_nombre . "-" . $this->_email . "\n"; 
	}
}
?>