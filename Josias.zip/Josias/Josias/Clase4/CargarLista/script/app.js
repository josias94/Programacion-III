var lista = [];

var TxtNombre;
var TxtEdad;

function Persona(nombre,edad){
    this.nombre = nombre;
    this.edad = edad;
}


window.addEventListener('load', asignarManejadores,false);

function asignarManejadores(){
    var frm = document.getElementById("frmAlta");
    //var frm = document.forms["frmAlta"];
    //var frm = document.forms[0];
    frm.addEventListener('submit',manejarEnvio);
    TxtNombre = document.getElementById("TxtNombre");
    TxtEdad = document.getElementById("TxtEdad");
    console.log(TxtNombre);
}

function manejarEnvio(e){
    e.preventDefault();
    CargarLista();
}

function CargarLista(){
    var P1 = new Persona(TxtNombre.value,parseInt(TxtEdad.value));
    
    lista.push(P1);

    RefrescarLista();
}

function RefrescarLista(){
    var table = "<table id='tablaPersonas'><tr><th>Nombre</th><th>Edad</th><tr>";

    for(var i = 0; i <lista.length; i++)
    {
        table += "<tr><td>" + lista[i]["nombre"]+ "</td><td>" +lista[i].edad+ "</td></tr>";
    }
    table += "</table>";
    document.getElementById("DivTabla").innerHTML = table;
}




