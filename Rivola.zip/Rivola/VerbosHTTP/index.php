<?php
echo "<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv='X-UA-Compatible' content='ie=edge'>
    <title>Index</title>
</head>
<body>
    <h4>Hola<br><br>GET: ";
    var_dump($_GET);

    echo "<br><br>POST: ";
    var_dump($_POST);
    
    echo "<br><br>REQUEST: ";
    var_dump($_REQUEST);

    //echo "<br><br>COOKIE: ";
    //setcookie($laCookie = "hola");
    //var_dump($_COOKIE);//ME TRAE UN ARRAY VACIO

    //echo "<br><br>SESSION: ";
    //var_dump($_SESSION);





    

    echo "
    </h4>
</body>
</html>";

?>