<?php

class Funciones
{
    public static function Alta($path, $obj)
    {
        $arrayAux = json_decode(Funciones::Leer($path));   
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        array_push($arrayTemp, $obj);

        Funciones::Escribir($path, $arrayTemp);
    }

    public static function Leer($path)
    {
        $arrayJson = [];
        $archivo = fopen($path,"r");
        $len = filesize($path);
        if($len > 0)
        {
            $arrayJson = fread($archivo,$len);
        }
        fclose($archivo);
        return $arrayJson;
    }
    
    public static function Listar($path)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        return $arrayAux;
    }

    public static function Modificar($path, $idName, $idValue, $key, $newValueKey)
    {
        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = []; 
        foreach($arrayTemp as $elem)
        {            
            if(isset($elem->$key) && isset($elem->$idName))
            {
                if($elem->$idName == $idValue)
                {
                    $elem->$key = $newValueKey;
                    break;
                }
            }
        }
        Funciones::Escribir($path, $arrayTemp);
        return $arrayTemp;
    }


    public static function Borrar($path, $args)
    {
        $legajo = $args;

        $arrayAux = json_decode(Funciones::Leer($path));
        $arrayAux != null ? $arrayTemp = $arrayAux : $arrayTemp = array();
        $arrayFinal = array();
        foreach($arrayTemp as $elem)
        {
            if($elem->legajo != $legajo)
            {
                array_push($arrayFinal,$elem);
            }
        }
        Funciones::Escribir($path, $arrayFinal);
    }

    public static function Escribir($path, $arrayObj)
    {
        $archivo = fopen($path,"w");
        fwrite($archivo,json_encode($arrayObj));
        fclose($archivo);
    }
}

?>